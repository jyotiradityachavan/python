class Demo:
    var1 = "Hello"
    var2 = "welcome"

    def fun(self):
        print("H1", self.var1)
        print("H1", self.var2)

# To use the class and call the method
obj = Demo()
obj.fun()
