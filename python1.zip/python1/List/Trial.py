my_list = [3, 1, 2]
result = my_list.sort()
print(result)  # This will print 'None'

result = my_list.pop(0)
print(result)  # This will print the value removed, not 'None'
