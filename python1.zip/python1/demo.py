from mypackage import module1,module2
answer=module1.add()
print(answer)