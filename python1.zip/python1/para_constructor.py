class Demo:
    def __init__(self):
        self.str = "Welcome"

    def display(self):
        print(self.str)
obj = Demo()
obj.display()
