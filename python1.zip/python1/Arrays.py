# import array as arr
# a=arr.array('h',[1,2,3])
# for i in range (0,3):
#     print (a[i],end=" ")
# b=arr.array('L',[3,4,5])
# for i in range (1,3):
#     print(b[i],end=" ")    



import array as arr
numbers=arr.array('i',[5,7,8,9])
# print(numbers)

# insert
# numbers.insert(1,9)
# for x in numbers:
#     print(x)

# deletion
# numbers.remove(7)
# for x in numbers:
#     print(x)

# numbers.count(x)
