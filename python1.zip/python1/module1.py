def add():
    a=int(input("Enter the first number:"))
    b=int(input("Enter second number:"))
    return a+b