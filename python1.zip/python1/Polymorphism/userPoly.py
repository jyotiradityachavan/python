def add(a,d):
    return a+d

print(add(4,2))