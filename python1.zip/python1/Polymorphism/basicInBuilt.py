print(len("Rutu patil"))
print(len(["Ruturaj","Patil",12,"Kolhapur"]))
print(len({"name":"Ruturaj","age":21}))
print(len({"Rutu patil","Cse","third year"}))