# import os
# print("String format:",os.getcwd)
# print("Byte string format:",os.getcwdb())



