import module1,module2
res1=module1.add()
print(res1)
res2=module2.sub()
print(res2)